/* EN EL MAIN ESTO SE UTILIZARÍA ASÍ

// 1. CREAR EL OBJETO
I2CMaster i2cBus(I2C_NUM_0, GPIO_NUM_21, GPIO_NUM_22, 100000);

void app_main() {
    i2cBus.init();
    i2cBus.writeBytes(0x68, 0x1B, 0x08, 1)
    i2cBus.writeBytes(slaveAddr, regAddr, *data, length)

    // 3. EJEMPLO DE LECTURA: Leer 2 bytes de datos (ej: Registro de datos 0x3B)
    uint8_t sensorData[2] = {0};
    if (i2cBus.readBytes(0x68, 0x3B, sensorData, 2)) {
        printf("Lectura exitosa. Byte 1: %02X, Byte 2: %02X\n", sensorData[0], sensorData[1]);
    } else {
        printf("Error al leer por I2C\n");
    }
}
*/

#include "I2C.h"

I2CMaster::I2CMaster(i2c_port_t port, int sdaPin, int sclPin, uint32_t speedHz){
    _port = port; 
    _sdaPin = sdaPin; 
    _sclPin = sclPin; 
    _speedHz = speedHz;
}

void I2CMaster::init(){
    i2c_config_t conf = {
		.mode = I2C_MODE_MASTER,
		.sda_io_num = _sdaPin, 
		.scl_io_num = _sclPin, 
		.sda_pullup_en = GPIO_PULLUP_ENABLE,
		.scl_pullup_en = GPIO_PULLUP_ENABLE,
		.master = { .clk_speed = _speedHz},
        .clk_flags = 0
	};
	i2c_param_config(_port, &conf); 
	i2c_driver_install(_port, conf.mode, 0, 0, 0);
	
}

bool I2CMaster::readBytes(uint8_t slaveAddr, uint8_t regAddr, uint8_t *data, size_t length){
    if (length == 0) return false; 

    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    //Apuntar al Address y register que se quiere leer
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (slaveAddr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, regAddr, true); 

    //Otra vez start para modo lectura (escribir para leer)
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (slaveAddr << 1) | I2C_MASTER_READ, true); 
    if (length > 1) {
        i2c_master_read(cmd, data, length -1, I2C_MASTER_ACK);
    };
    i2c_master_read_byte(cmd, data + length-1, I2C_MASTER_NACK); 
    i2c_master_stop(cmd); 
    esp_err_t err = i2c_master_cmd_begin(_port, cmd, pdMS_TO_TICKS(1000)); 
    i2c_cmd_link_delete(cmd);
    return (err == ESP_OK);
}

bool I2CMaster::writeBytes(uint8_t slaveAddr, uint8_t regAddr, uint8_t *data, size_t length){
    if (length == 0) return false; 

    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    //Apuntar al Address y register que se quiere leer
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (slaveAddr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, regAddr, true); 

    for (size_t i = 0; i < length; i++) {
        i2c_master_write_byte(cmd, data[i], true);
    }

    i2c_master_stop(cmd);
    
    esp_err_t err = i2c_master_cmd_begin(_port, cmd, pdMS_TO_TICKS(1000)); 
    i2c_cmd_link_delete(cmd);
    return (err == ESP_OK);
}

I2CMaster::~I2CMaster()
{
}